

package com.group47.project.fragment;

/**
 * The HomeFragment is a {@link BaseArticlesFragment} subclass that
 * reuses methods of the parent class
 */
public class HomeFragment extends BaseArticlesFragment {

    public static final String LOG_TAG = HomeFragment.class.getName();

}
